function [Peaks_filtered] = plot_spectrum(conc_path,Signal_energy)
%PLOT_SPECTRUM Summary of this function goes here
%   Detailed explanation goes here

% 
disp(conc_path)
size_csv = size(conc_path);
size_csv = size_csv(1,1);

j = 1;

conc_cells      = {};
conc_cells_name = {};

    for i = 1: size_csv

            temp               = strcat(conc_path(i).folder , '/' , conc_path(i).name);
            conc_cells{j}      = temp;
            conc_cells_name{j} = conc_path(i).name;
            j = j+1;

    end


data_file = {};

fig       = figure;


%full_fig = figure('Position', get(0, 'Screensize'));

    for m = 1: length(conc_cells)
        
            display(conc_cells{m});
            data_file = table2array(readtable(conc_cells{m}));

            %Filtering using cheby10 for 2.25MHz
            %display(conc_cells{m});
            
            [b_BPF,a_BPF]  = cheby1(2, 0.001, [0.002,0.016],'bandpass');
            xq             = 10:0.25:600;
            
            display(size(data_file));
            
            vq1            = interp1((10:1:600),data_file(10:1:600,2),xq,'cubic');
            Filtered_sig   = filtfilt(b_BPF,a_BPF,vq1);
            Filtered_sig   = Filtered_sig./Signal_energy(m);

            plot(Filtered_sig,'linewidth',1.5,'LineStyle','-', 'DisplayName', conc_cells_name{m});
            hold on
            xlabel('Time Samples')
            ylabel('PA amplitude(mV)')

            legend('show',  'location','northeast')
    end

            original_path   = conc_cells{1};
            modified_path   = strrep(original_path,'Data/','plots/');
            index           = strfind(modified_path, '/');
            last_index      = index(1,size(index));
            last_index      = last_index(1,2);
            save_dir        = extractBefore(modified_path, last_index);
    
     if ~exist(save_dir, 'dir')
       mkdir(save_dir)
     end
     
     save_path = strcat(save_dir,'.png')
    
    %full_fig = figure('Position', get(0, 'Screensize'));
    saveas(gcf,save_path)
    
% For interactive point selection on raw signals
% Enable data cursor mode
datacursormode on
dcm_obj = datacursormode(fig);
% Set update function
set(dcm_obj,'UpdateFcn',@myupdatefcn)
% Wait while the user to click
disp('Click line to display a data tip, then press "Return"')
pause 
% Export cursor to workspace
info_struct = getCursorInfo(dcm_obj);
if isfield(info_struct, 'Position')
  disp('Clicked positioin is')
  disp(info_struct.Position)
end
function output_txt = myupdatefcn(~,event_obj)
  % ~            Currently not used (empty)
  % event_obj    Object containing event data structure
  % output_txt   Data cursor text
  pos = get(event_obj, 'Position');
  output_txt = {['x: ' num2str(pos(1))], ['y: ' num2str(pos(2))]};
end


cutoff = info_struct.Position(1);
% cutoff = 1000
close(fig);

% fig2 = figure;


%full_fig = figure('Position', get(0, 'Screensize'));
    for m = 1: length(conc_cells)
            display(conc_cells{m});
            data_file = table2array(readtable(conc_cells{m}));

            %Filtering using cheby10 for 2.25MHz
            %display(conc_cells{m});
            
            [b_BPF,a_BPF]       = cheby1(2, 0.001, [0.002,0.016],'bandpass');
            xq                  = 10:0.25:600;
            
            display(size(data_file));
            
            vq1                 = interp1(10:1:600,data_file(10:1:600,2),xq,'cubic');
            Filtered_sig        = filtfilt(b_BPF,a_BPF,vq1);
            Filtered_sig        = Filtered_sig./Signal_energy(m);
            y                   = hilbert( Filtered_sig);
            Filtered_AUC_BSA(m) = trapz(abs(y(120:length(y))));
    end

    Wavelength                 = 1280:20:1600;
    Wavelenghtxq               = 1280:0.1:1600;
    Peaks_filtered             = (Filtered_AUC_BSA)./max(Filtered_AUC_BSA);
    Scaled_peaks               = rescale(Peaks_filtered,min(Filtered_AUC_BSA),max(Filtered_AUC_BSA));
    interpolated_peaks         = interp1(Wavelength,Peaks_filtered,Wavelenghtxq,'spline');
    
    original_path_modified     = conc_cells{1};
    original_path_modified     = strsplit(original_path_modified,'/');

                  newcolors    = [ 0.83 0.14 0.14
                                 1.00 0.54 0.00
                                 0.47 0.25 0.100
                                 0.25 0.100 0.54
                                 0.9290 0.6940 0.1600
                                 0.4940 0.1840 0.5560
                                 0.4660 0.6740 0.18100
                                 0.3010 0.7450 0.9600
                                 0 0 0
                                 1 1 0
                                 1 0 1
                                 0 1 1 ];

    colororder(newcolors)
    
    plot(Wavelenghtxq,interpolated_peaks,'linewidth',2.5,'LineStyle','-','DisplayName', original_path_modified{10})
    hold on,
    
    ax            =  gca;
    ax.FontSize   =  22;
    ax.FontName   = 'C059';
    ax.FontWeight = 'bold';

    
    xlabel('Wavelength(nm)')
    ylabel('PA amplitude(a.u)')
    title('Spectrum, V')
    legend('show',  'location','northeast')

    
    original_path         = conc_cells{1};
    modified_path_spectra = strrep(original_path,'Data/','plots/');
    index                 = strfind(modified_path_spectra, '/');
    last_index            = index(1,size(index));
    last_index            = last_index(1,2);
    save_dir              = original_path_modified{10};
%     
     if ~exist(save_dir, 'dir')
       mkdir(save_dir)
     end
%      
     save_path = strcat(modified_path_spectra,save_dir,'.png')
    
%     full_fig = figure('Position', get(0, 'Screensize'));
    saveas(gcf,save_path)
    

end

