function [Peaks_filtered] = analyse_csv(conc_path,Signal_energy)
%ANALYSE_CSV Summary of this function goes here
%   Detailed explanation goes here

% comment the other function that does not require plotting and use

Peaks_filtered = spectrum_subtracted2(conc_path,Signal_energy); 

% Peaks_filtered = plot_spectrum(conc_path,Signal_energy);

% fit_points_temp = conc_fitting(conc_path,Signal_energy); 



end


