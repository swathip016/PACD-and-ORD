function [a_in] = spectrum_analyse(conc_paths,Signal_energy)
%SPECTRUM_ANALYSE Summary of this function goes here
%   Detailed explanation goes here
Concentration_used  = [50, 70, 90, 120, 170, 200, 250, 300, 350, 400, 2000, 00];% Only used for fitting purposes

concentration = dir(conc_paths);  % polar directory contains data for all types of polarization
concentration = concentration(~ismember({concentration.name},{'.','..'}));
Spectra = [];
size_csv = size(concentration);
size_csv = size_csv(1,1);
a_in = {};
    for i = 1:size_csv
    
        conc_path = strcat(concentration(i).folder , '/' , concentration(i).name);
        data      = dir(conc_path);
        data      = data(~ismember({data.name},{'.','..'}));
        
        len = size(data);
        len = len(1,1);
       
        if(len ~= 0)
             
              Spectra = analyse_csv(data,Signal_energy);
             
        end
       a_in{i} = Spectra;
       
       %Plotting the fitted curves at different wavelengths
       
    end
%     figure()
%     p = polyfit(Concentration_used, a_in, 2); 
%     f = polyval(p, Concentration_used); 
%     plot(Concentration_used(1:10), a_in(1:10),'o', Concentration_used, f,'-') 
%     legend('data','linear fit') 
end

