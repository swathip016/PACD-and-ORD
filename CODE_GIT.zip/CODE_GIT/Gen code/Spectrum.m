clear;
close all;
clc;
%% Data  Paths

data_paths = "/home/fistlab/Documents/MFC/CD 27 Aug/Data/";
polar      = dir(data_paths); % polar directory contains data for all types of polarization
polar      = polar(~ismember({polar.name},{'.','..'})); 


%% Energy Measured using energy meter

Idler_energy_V = [268,214,186,160,125,114,75.8,67,66,66,68,91,90,88,85,89,74].*1e-6.*15.667.*0.8118;

Idler_energy_P = [1.95500000000000,1.73000000000000,1.66700000000000,1.80500000000000,1.78000000000000,1.83000000000000,1.77300000000000,1.61100000000000,1.39000000000000,1.05500000000000,0.719000000000000,0.802000000000000,1.13500000000000,1.21300000000000,1.17400000000000,1.07200000000000,0.904000000000000
].*1e-3;
Idler_energy_R = [2.45000000000000,2.15000000000000,1.98000000000000,2.03000000000000,1.94400000000000,2.22140000000000,1.82200000000000,1.55700000000000,1.23300000000000,0.904000000000000,0.700000000000000,1.06300000000000,1.21700000000000,1.24000000000000,1.13000000000000,0.989000000000000,0.801000000000000
].*1e-3;
%% Energy in ideal case using Malus' Law calculations

Idler_testV = [16.2 14.6 11.5	10.2	9.45	8.58	6.4	4.16	5.707	4.25	3.44	2.56	2.22
].*1e-3;
Idler_testP = [15.05	12.34	11.8	10.77	8.6	8.05	6.5	3.9	4.48	4.24	3.26	2.38	2.06
].*1e-3;
Idler_testR = [7.61	6	5.88	4.43	3.5	3.58	3.02	1.8	1.39	2.02	1.59	1.12	0.956
].*1e-3;


%% Vertical Incidence
vertical_data_path = strcat(polar(3).folder , '/' , polar(3).name);

estimated_peaksV = spectrum_analyse(vertical_data_path,Idler_energy_V);

%% Linear Incidence
linear_data_path   = strcat(polar(2).folder , '/' , polar(2).name);

estimated_peaksP = spectrum_analyse(linear_data_path,Idler_energy_V);

%% Circular Incidence
circular_data_path = strcat(polar(1).folder , '/' , polar(1).name);

estimated_peaksR = spectrum_analyse(circular_data_path,Idler_energy_V);

%%
Wavelength  = 1280:20:1600;
Spectra_LCP = cell2mat(estimated_peaksR');
Spectra_RCP = cell2mat(estimated_peaksV');

CD   = Spectra_LCP(1,:)-Spectra_RCP(1,:);
CDSI = (Spectra_LCP(1,:)-Spectra_RCP(1,:))./(Spectra_LCP(1,:)+Spectra_RCP(1,:));

figure,
plot(Wavelength,CD)


