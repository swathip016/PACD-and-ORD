function [Peaks_filtered] = spectrum_subtracted2(conc_path,Signal_energy,Bounds)
%HELPER Summary of this function goes here
%   Detailed explanation goes here
disp(conc_path)
size_csv = size(conc_path);
size_csv = size_csv(1,1);

j = 1;

conc_cells      = {};
conc_cells_name = {};
conc_cells_bsa  = {};
           
            
    for i = 1: size_csv

            temp          = strcat(conc_path(i).folder , '/' , conc_path(i).name);
            conc_cells{j} = temp;

    %         display(temp_bsa{});
            original_path = temp;
            index         = strfind(original_path, '/');
            index_1       = index(size(index,2));
            index_2       = index(size(index,2)-1);
            final         = extractBefore(original_path,index_2+1) + "BSA" +extractAfter(original_path,index_1-1);
            path_bsa      = final;

            display(temp);
            display(path_bsa)

            conc_cells_bsa{j}  = path_bsa;

            conc_cells_name{j} = conc_path(i).name;

            j = j+1;

    end


data_file = {};

fig       = figure;
            Samples        = 1:1:1400;
            F_s_new        = 20*1e6;
            Sig_time       = Samples./F_s_new;
            TIme_to_dist   = Sig_time.*(1420*1000);

           
            xq             = 1:0.25:1400;
            
            new_d = interp1(1:1:1400,TIme_to_dist(1:1400),xq);

    %full_fig = figure('Position', get(0, 'Screensize'));
    for m = 1: length(conc_cells)

            display(conc_cells{m});
            data_file     = table2array(readtable(conc_cells{m}));

            %Filtering using cheby1 for 2.25MHz
            %display(conc_cells{m});
            
            [b_BPF,a_BPF] = cheby1(2, 0.001, [0.003,0.01],'bandpass');
            xq            = 1:0.25:1000;
            
            display(size(data_file));
            
            vq1           = interp1(1:1:1000,data_file(1:1:1000,2),xq,'cubic');
            Filtered_sig  = filtfilt(b_BPF,a_BPF,vq1);
            Filtered_sig  = Filtered_sig./Signal_energy(m);

            plot(Filtered_sig,'linewidth',1.5,'LineStyle','-', 'DisplayName', conc_cells_name{m});
            hold on
            xlabel('Time Samples')
            ylabel('PA amplitude(mV)')
            legend('show',  'location','northeast')
    end

    original_path   = conc_cells{1};
    modified_path   = strrep(original_path,'Data/','plots/');
    index           = strfind(modified_path, '/');
    last_index      = index(1,size(index));
    last_index      = last_index(1,2);
    save_dir        = extractBefore(modified_path, last_index);
    
     if ~exist(save_dir, 'dir')
       mkdir(save_dir)
     end
     
     save_path = strcat(save_dir,'.png')
    
    %full_fig = figure('Position', get(0, 'Screensize'));
    saveas(gcf,save_path)
    
 %For interactive point selection on raw signals
% Enable data cursor mode
% datacursormode on
% dcm_obj = datacursormode(fig);
% % Set update function
% set(dcm_obj,'UpdateFcn',@myupdatefcn)
% % Wait while the user to click
% disp('Click line to display a data tip, then press "Return"')
% pause 
% % Export cursor to workspace
% info_struct = getCursorInfo(dcm_obj);
% if isfield(info_struct, 'Position')
%   disp('Clicked positioin is')
%   disp(info_struct.Position)
% end
% function output_txt = myupdatefcn(~,event_obj)
%   % ~            Currently not used (empty)
%   % event_obj    Object containing event data structure
%   % output_txt   Data cursor text
%   pos = get(event_obj, 'Position');
%   output_txt = {['x: ' num2str(pos(1))], ['y: ' num2str(pos(2))]};
% end
% 
% 
% 
% cutoff = info_struct.Position(1);
% 
% cutoff = 530
close(fig);
% 
%     Water_lower_limits = [1030, 1000, 1050, 1010, 1010, 1000,1000, 960, 970, 970, 980, 970, 965, 970, 930, 950, 960, 950, 920, 990, 990];
%     Water_upper_limits = [1125, 1150, 1140, 1190, 1190, 1160, 1160, 1110, 1140, 1150, 1200, 1200, 1200, 1210, 1205, 1190, 1195, 1195, 1240, 1170, 1180];
%     Lower              = Bounds(:,1);
%     Upper              = Bounds(:,2);
    for m = 1: length(conc_cells)

            display(conc_cells{m});
            data_file_BSA        = table2array(readtable(conc_cells_bsa{m}));

            display(conc_cells_bsa{m});
            data_file            = table2array(readtable(conc_cells{m}));

%             data_file_subtracted = data_file(1:1400,2) - data_file_BSA(1:1400,2);

            %Filtering using cheby1 for 2.25MHz
            %display(conc_cells{m});
            [b_BPF,a_BPF]       = cheby1(2, 0.001, [0.003,0.01],'bandpass');
            xq                  = 1:0.25:1000;
%             display(size(data_file_subtracted));
             

            vq1                 = interp1(1:1:1000,data_file_BSA(1:1:1000,2),xq,'cubic');
            Filtered_sig        = filtfilt(b_BPF,a_BPF,vq1);
            Filtered_sig        = Filtered_sig./Signal_energy(m);
            y                   = hilbert(Filtered_sig);
            Filtered_AUC_BSA(m) = trapz(abs(y(1:end)));
%            Filtered_AUC_BSA(m) = max(Filtered_sig(1490:1680))- min(Filtered_sig(1490:1680));

            vq2                  = interp1(1:1:1000,data_file(1:1:1000,2),xq,'cubic');
            Filtered_sig2        = filtfilt(b_BPF,a_BPF,vq2);
            Filtered_sig2        = Filtered_sig2./Signal_energy(m);
            y2                   = hilbert( Filtered_sig2);
            Filtered_AUC_BSA2(m) = trapz(abs(y2(1:end)));  
%            
%              Filtered_AUC_BSA2(m) = max(Filtered_sig2(1490:1680))- min(Filtered_sig2(1490:1680));

%             plot(Filtered_sig2,'linewidth',1.5,'LineStyle','-', 'DisplayName', conc_cells_name{m});
%             hold on

    end

     Wavelength              = 1280:20:1600;
     Wavelenghtxq            = 1280:0.1:1600;
     %Filtered_AUC_BSA21      = interp1(Wavelength, Filtered_AUC_BSA2, Wavelenghtxq, 'cubic');
     %Filtered_AUC_BSA1      = interp1(Wavelength, Filtered_AUC_BSA, Wavelenghtxq, 'cubic');
%      Filtered_AUC_BSA3       = ((Filtered_AUC_BSA2)./max(Filtered_AUC_BSA2)) -  ((Filtered_AUC_BSA)./max(Filtered_AUC_BSA));  
%     Filtered_AUC_BSA3       = ((Filtered_AUC_BSA2(1:2:21)./max(Filtered_AUC_BSA2(1:2:21)))) -  (Filtered_AUC_BSA(1:2:21)./max(Filtered_AUC_BSA(1:2:21)));  
    
    Filtered_AUC_BSA3       = ((Filtered_AUC_BSA)) -  ((Filtered_AUC_BSA2));      
    Peaks_filtered          = (Filtered_AUC_BSA2);
     
     if (Filtered_AUC_BSA3 == 0)
         return
     else
%      Scaled_peaks            = rescale(Peaks_filtered, min(Filtered_AUC_BSA2), max(Filtered_AUC_BSA2));
     interpolated_peaks      = interp1(Wavelength, Peaks_filtered, Wavelenghtxq, 'cubic');
     end
     
    original_path_modified   = conc_cells{1};
    original_path_modified   = strsplit(original_path_modified,'/');
    
                newcolors    = [ 0.83 0.14 0.14
                                 1.00 0.54 0.00
                                 0.47 0.25 0.100
                                 0.25 0.100 0.54
                                 0.9290 0.6940 0.1250
                                 0.4940 0.1840 0.5560
                                 0.4660 0.6740 0.18100
                                 0.3010 0.7450 0.91000
                                 0 0 0
                                 1 1 0
                                 1 0 1
                                 0 1 1 ];

    colororder(newcolors)

    plot(Wavelenghtxq, interpolated_peaks, 'linewidth', 3.5, 'LineStyle','-', 'DisplayName', original_path_modified{9})
    hold on,
    
    ax            =  gca;
    ax.FontSize   =  28;
    ax.FontName   = 'C059';
    ax.FontWeight = 'bold';

    
    xlabel('Wavelength(nm)')
    ylabel('PA amplitude(a.u)')
%     title('Spectrum, V')
    legend('show',  'location','northeast')

        
    original_path   = conc_cells{1};
    modified_path   = strrep(original_path,'Data/','plots/');
    index           = strfind(modified_path, '/');
    last_index      = index(1,size(index));
    last_index      = last_index(1,2);
    save_dir1       = original_path_modified{10};
%     
     if ~exist(save_dir1, 'dir')
       mkdir(save_dir1)
     end
%      
     save_path = strcat(save_dir1,'subtracted','.png')
    
%     full_fig = figure('Position', get(0, 'Screensize'));
    saveas(gcf,save_path)
    
%     close(fig3);
    
         
    
end

